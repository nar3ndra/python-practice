/* --- PART 000001 START --- */
/* Data Step | Outputs: WORK.CLAIMS | Inputs: None */
data claims;
    input claim_id policy_id claim_date :date9. claim_amount status $;
    format claim_date date9.;
    datalines;
1001 2001 01JAN2024 5000 Open
1002 2002 15JAN2024 12000 Closed
1003 2001 20FEB2023 3500 Closed
1004 2003 05MAR2024 8000 Open
1005 2002 10MAR2024 15000 Closed
1006 2004 25APR2024 6500 Open
1007 2003 30APR2024 9000 Closed
1008 2005 15MAY2024 4000 Open
;
run;
/* --- PART 000001 END --- */

/* --- PART 000002 START --- */
/* Data Step | Outputs: WORK.POLICIES | Inputs: None */
data policies;
    input policy_id policy_type $ premium province $;
    datalines;
2001 Auto 1200 QC
2002 Home 2500 ON
2003 Auto 1500 QC
2004 Home 3000 BC
2005 Auto 1100 ON
;
run;
/* --- PART 000002 END --- */

/* --- PART 000003 START --- */
/* Data Step | Outputs: WORK.CLAIMS_ENHANCED | Inputs: WORK.CLAIMS */
data claims_enhanced;
    set claims;
    
    /* Calculate days since claim */
    days_since_claim = today() - claim_date;
    
    /* Apply format to claim_category to avoid truncation */
    length claim_category $10.;
    
    /* Categorize claim amount */
    if claim_amount < 5000 then claim_category = 'Small';
    else if claim_amount < 10000 then claim_category = 'Medium';
    else claim_category = 'Large';
    
    /* Flag high priority claims */
    if status = 'Open' and claim_amount > 7000 then priority = 'High';
    else priority = 'Normal';
run;
/* --- PART 000003 END --- */

/* --- PART 000004 START --- */
/* Proc Sort | Outputs: WORK.SORTED_CLAIMS | Inputs: WORK.CLAIMS_ENHANCED */
proc sort data=claims_enhanced out=sorted_claims;
    by descending claim_date;
run;
/* --- PART 000004 END --- */

/* --- PART 000005 START --- */
/* Proc Sql | Outputs: WORK.CLAIMS_WITH_POLICY | Inputs: WORK.SORTED_CLAIMS, WORK.POLICIES */
proc sql;
    create table claims_with_policy as
    select 
        c.claim_id,
        c.policy_id,
        c.claim_date,
        c.claim_amount,
        c.status,
        c.claim_category,
        c.days_since_claim,
        p.policy_type,
        p.premium,
        p.province,
        c.claim_amount / p.premium as loss_ratio format=8.2
    from sorted_claims as c
    inner join policies as p
        on c.policy_id = p.policy_id
    order by p.province, c.claim_date;
quit;
/* --- PART 000005 END --- */

/* --- PART 000006 START --- */
/* Proc Means | Outputs: WORK.CLAIM_SUMMARY | Inputs: WORK.CLAIMS_WITH_POLICY */
proc means data=claims_with_policy n mean sum std min max;
    class province policy_type;
    var claim_amount premium loss_ratio;
    output out=claim_summary
        n=n_claims
        mean=avg_claim avg_premium avg_loss_ratio
        sum=total_claims total_premium;
run;
/* --- PART 000006 END --- */

/* --- PART 000007 START --- */
/* Proc Print | Outputs: None | Inputs: WORK.CLAIMS_WITH_POLICY */
proc print data=claims_with_policy;
    title 'Claims with Policy Details';
run;
/* --- PART 000007 END --- */

/* --- PART 000008 START --- */
/* Proc Print | Outputs: None | Inputs: WORK.CLAIM_SUMMARY */
proc print data=claim_summary;
    title 'Claims Summary by Status and Category';
run;
/* --- PART 000008 END --- */

/* --- PART 000009 START --- */
/* Data Step | Outputs: WORK.CLAIMS_ENHANCED | Inputs: WORK.CLAIMS_ENHANCED */
data claims_enhanced;
    set claims_enhanced;
    /* Add additional processing */
    if priority = 'High' then escalation_required = 'Yes';
    else escalation_required = 'No';
run;
/* --- PART 000009 END --- */

/* --- PART 000010 START --- */
/* Proc Print | Outputs: None | Inputs: WORK.CLAIMS_ENHANCED */
proc print data=claims_enhanced;
    title 'Final Enhanced Claims';
run;
/* --- PART 000010 END --- */
