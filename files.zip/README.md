# SAS Code Splitter - MVP Version 1

A Python-based tool that decomposes SAS code into smaller chunks without introducing regression, designed to support SAS-to-Python migration pipelines.

## Overview

This tool is the **Splitter** component of the AI Orchestrator pipeline for converting SAS code to Python. It takes a SAS script and:

1. **Identifies optimal split points** (DATA steps, PROC steps, PROC SQL, etc.)
2. **Marks output tables** for each chunk (for Snowflake migration)
3. **Tracks table overwrites** so the converter knows which chunks can be validated independently
4. **Generates validation scripts** to compare original vs chunked outputs

## Features

### ✅ MVP Version 1 Features

| Feature | Description | Status |
|---------|-------------|--------|
| Code Splitting | Split SAS code at logical boundaries | ✅ Complete |
| Output Table Identification | Identify all tables created by each chunk | ✅ Complete |
| Table Overwrite Detection | Track when tables are overwritten by later chunks | ✅ Complete |
| Validation Script Generation | Generate SAS scripts to validate split correctness | ✅ Complete |
| Snowflake DDL Generation | Generate CREATE TABLE statements for migration | ✅ Complete |
| Migration Manifest | JSON manifest for downstream processing | ✅ Complete |

### 🔮 Future Version Features

| Feature | Description | Status |
|---------|-------------|--------|
| Difficulty Level Assessment | Rate chunk conversion complexity | Planned |
| Macro Expansion | Expand macros before splitting | Planned |
| Dependency Graph | Visual representation of chunk dependencies | Planned |

## Installation

```bash
# Clone the repository
cd sas_splitter

# Install dependencies (optional - core features work without dependencies)
pip install -r requirements.txt
```

## Usage

### Quick Start - Full Pipeline

```bash
python main.py full my_script.sas --output-dir ./output
```

This generates:
- `my_script_split.sas` - Split SAS code with PART markers
- `my_script_metadata.json` - Chunk and table metadata
- `my_script_snowflake.sql` - Snowflake DDL for migration
- `my_script_manifest.json` - Migration manifest
- `my_script_validation.sas` - SAS validation script

### Individual Commands

#### Split SAS Code
```bash
python main.py split input.sas --output-dir ./output --verbose
```

#### Generate Validation Script
```bash
python main.py validate output/input_metadata.json input.sas output/input_split.sas
```

#### Track Output Tables
```bash
python main.py track output/input_metadata.json --ddl --manifest
```

#### Generate Report
```bash
python main.py report output/input_metadata.json --format html
```

## Output Files

### Split SAS File (`*_split.sas`)

Each chunk is wrapped with PART markers:

```sas
/* --- PART 000001 START --- */
/* Data Step | Outputs: WORK.CLAIMS | Inputs: None */
data claims;
    input claim_id policy_id claim_date :date9.;
    ...
run;
/* --- PART 000001 END --- */

/* --- PART 000002 START --- */
/* Data Step | Outputs: WORK.POLICIES | Inputs: None */
data policies;
    ...
run;
/* --- PART 000002 END --- */
```

### Metadata JSON (`*_metadata.json`)

Contains complete information about each chunk:

```json
{
  "chunks": [
    {
      "chunk_id": 1,
      "chunk_type": "DATA_STEP",
      "output_tables": [{"name": "CLAIMS", "library": "WORK", "is_overwritten": false}],
      "input_tables": [],
      "can_validate_independently": true
    }
  ],
  "overwritten_tables": ["WORK.CLAIMS_ENHANCED"],
  "final_output_tables": ["WORK.CLAIMS", "WORK.POLICIES", ...]
}
```

### Snowflake DDL (`*_snowflake.sql`)

Ready-to-use DDL for creating target tables:

```sql
CREATE DATABASE IF NOT EXISTS SAS_MIGRATION;
CREATE SCHEMA IF NOT EXISTS SAS_MIGRATION.PUBLIC;

CREATE TABLE IF NOT EXISTS SAS_MIGRATION.PUBLIC.CLAIMS (
    -- Column definitions to be added after SAS metadata extraction
);
```

### Validation Script (`*_validation.sas`)

Automated validation that:
1. Runs original SAS code and captures output table snapshots
2. Runs chunked SAS code and captures output table snapshots
3. Compares all final output tables using PROC COMPARE
4. Reports PASSED/FAILED status for each table

## Handling Table Overwrites

A key feature is detecting when SAS code overwrites the same table:

```sas
/* Chunk 3 creates claims_enhanced */
data claims_enhanced;
    set claims;
    /* ... processing ... */
run;

/* Chunk 9 overwrites claims_enhanced */
data claims_enhanced;
    set claims_enhanced;
    /* ... additional processing ... */
run;
```

The splitter:
1. **Detects** that `WORK.CLAIMS_ENHANCED` is written by chunks 3 and 9
2. **Marks** chunk 3 as `can_validate_independently: false`
3. **Notes** that chunk 3's output is overwritten by chunk 9
4. **Final validation** only compares the final state of the table

This ensures the SAS-to-Python converter knows:
- Chunk 3 cannot be validated in isolation
- Only the final `CLAIMS_ENHANCED` (from chunk 9) should be validated
- Snowflake migration should only capture the final table state

## Project Structure

```
sas_splitter/
├── main.py                  # CLI orchestrator
├── sas_code_splitter.py     # Core splitting logic
├── validation.py            # Validation script generation
├── output_tracker.py        # Snowflake migration tracking
├── requirements.txt         # Python dependencies
├── README.md               # This file
└── examples/
    ├── 01_basic_script.sas  # Example input
    └── output/              # Generated files
        ├── 01_basic_script_split.sas
        ├── 01_basic_script_metadata.json
        ├── 01_basic_script_snowflake.sql
        ├── 01_basic_script_manifest.json
        └── 01_basic_script_validation.sas
```

## Supported SAS Constructs

| Construct | Support Level | Notes |
|-----------|--------------|-------|
| DATA steps | ✅ Full | Including datalines/cards |
| PROC SQL | ✅ Full | CREATE TABLE, INSERT INTO |
| PROC SORT | ✅ Full | OUT= option detected |
| PROC MEANS | ✅ Full | OUTPUT statement detected |
| PROC PRINT | ✅ Full | DATA= option detected |
| PROC FREQ | ✅ Full | |
| PROC REPORT | ✅ Full | |
| PROC EXPORT | ✅ Full | |
| PROC IMPORT | ✅ Full | |
| %MACRO/%MEND | ⚠️ Basic | Treats as single chunk |
| LIBNAME | ✅ Full | Single-line statements |
| OPTIONS | ✅ Full | Single-line statements |

## Validation Workflow

```
┌─────────────────┐     ┌─────────────────┐
│  Original SAS   │     │   Split SAS     │
│    Script       │     │   (Chunked)     │
└────────┬────────┘     └────────┬────────┘
         │                       │
         ▼                       ▼
┌─────────────────┐     ┌─────────────────┐
│  Execute in     │     │  Execute in     │
│     SAS         │     │     SAS         │
└────────┬────────┘     └────────┬────────┘
         │                       │
         ▼                       ▼
┌─────────────────┐     ┌─────────────────┐
│   Capture       │     │   Capture       │
│   Snapshots     │     │   Snapshots     │
└────────┬────────┘     └────────┬────────┘
         │                       │
         └───────────┬───────────┘
                     │
                     ▼
            ┌─────────────────┐
            │  PROC COMPARE   │
            │  (Per Table)    │
            └────────┬────────┘
                     │
                     ▼
            ┌─────────────────┐
            │   Validation    │
            │    Report       │
            └─────────────────┘
```

## Integration with AI Orchestrator

This splitter is designed to feed into the SAS-to-Python conversion pipeline:

```
SAS Script
    │
    ▼
┌──────────────┐
│   SPLITTER   │  ← This tool
│  (This tool) │
└──────┬───────┘
       │
       ▼
┌──────────────┐     ┌──────────────┐
│  SAS Chunk   │────▶│   Python     │
│              │     │   Chunk      │
└──────────────┘     └──────────────┘
       │                    │
       ▼                    ▼
┌──────────────┐     ┌──────────────┐
│  Validation  │◀───▶│  Validation  │
│   (SAS)      │     │  (Python)    │
└──────────────┘     └──────────────┘
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Submit a pull request

## License

MIT License

## Contact

SAS to Python Migration Team
