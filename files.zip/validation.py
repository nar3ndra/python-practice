"""
SAS Chunk Validation Module
============================
Validates that SAS code chunks produce the same output as the original code.

This module provides:
1. Validation script generation for SAS
2. Output comparison logic
3. Regression detection
4. Validation report generation

Author: SAS to Python Migration Team
"""

import json
import hashlib
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple
from pathlib import Path
from datetime import datetime
from enum import Enum


class ValidationStatus(Enum):
    """Status of a validation check"""
    PASSED = "PASSED"
    FAILED = "FAILED"
    SKIPPED = "SKIPPED"
    NOT_APPLICABLE = "NOT_APPLICABLE"
    ERROR = "ERROR"


@dataclass
class TableValidation:
    """Validation result for a single table"""
    table_name: str
    status: ValidationStatus
    original_row_count: Optional[int] = None
    chunk_row_count: Optional[int] = None
    original_checksum: Optional[str] = None
    chunk_checksum: Optional[str] = None
    column_differences: List[str] = field(default_factory=list)
    row_differences: int = 0
    notes: str = ""


@dataclass
class ChunkValidation:
    """Validation result for a chunk"""
    chunk_id: int
    status: ValidationStatus
    table_validations: List[TableValidation] = field(default_factory=list)
    execution_time: float = 0.0
    notes: str = ""


@dataclass
class ValidationReport:
    """Complete validation report"""
    original_file: str
    split_file: str
    timestamp: str
    overall_status: ValidationStatus
    chunk_validations: List[ChunkValidation] = field(default_factory=list)
    final_table_validations: List[TableValidation] = field(default_factory=list)
    summary: Dict = field(default_factory=dict)


class SASValidationGenerator:
    """
    Generates SAS validation scripts for comparing original vs chunked output.
    """
    
    def __init__(self, metadata_path: str):
        """
        Initialize with the metadata JSON from the splitter.
        
        Args:
            metadata_path: Path to the _metadata.json file
        """
        with open(metadata_path, 'r') as f:
            self.metadata = json.load(f)
        
        self.chunks = self.metadata['chunks']
        self.final_tables = self.metadata['final_output_tables']
        self.overwritten_tables = set(self.metadata['overwritten_tables'])
        self.validation_ready = self.metadata['validation_ready_chunks']
    
    def generate_table_snapshot_macro(self) -> str:
        """Generate SAS macro for taking table snapshots"""
        return '''
/* Macro to capture table snapshot (row count and hash) */
%macro table_snapshot(table=, prefix=, outlib=WORK);
    /* Get row count */
    proc sql noprint;
        select count(*) into :&prefix._rowcount
        from &table;
    quit;
    
    /* Create snapshot copy */
    data &outlib..&prefix._snapshot;
        set &table;
    run;
    
    /* Generate hash for comparison */
    proc sql noprint;
        select md5(cats(of _all_)) into :&prefix._hash separated by ''
        from &table;
    quit;
    
    %put NOTE: Snapshot for &table - Rows: &&&prefix._rowcount;
%mend table_snapshot;
'''
    
    def generate_table_compare_macro(self) -> str:
        """Generate SAS macro for comparing two tables"""
        return '''
/* Macro to compare two tables */
%macro compare_tables(base=, compare=, outlib=WORK, report_name=);
    proc compare base=&base compare=&compare
        out=&outlib..&report_name._diff
        outnoequal outbase outcompare outdif
        method=absolute criterion=0.00001;
    run;
    
    /* Capture comparison result */
    %global &report_name._match;
    %if &sysinfo = 0 %then %do;
        %let &report_name._match = PASSED;
        %put NOTE: Tables &base and &compare are IDENTICAL;
    %end;
    %else %do;
        %let &report_name._match = FAILED;
        %put WARNING: Tables &base and &compare have DIFFERENCES;
    %end;
%mend compare_tables;
'''
    
    def generate_validation_sas(self, original_sas_path: str, 
                                 split_sas_path: str,
                                 output_dir: str = ".") -> str:
        """
        Generate a complete SAS validation script.
        
        Args:
            original_sas_path: Path to original SAS file
            split_sas_path: Path to split SAS file
            output_dir: Directory for validation outputs
            
        Returns:
            SAS code for validation
        """
        lines = []
        
        # Header
        lines.append("/*" + "=" * 70 + "*/")
        lines.append("/* SAS CHUNK VALIDATION SCRIPT")
        lines.append(f"/* Generated: {datetime.now().isoformat()}")
        lines.append(f"/* Original File: {original_sas_path}")
        lines.append(f"/* Split File: {split_sas_path}")
        lines.append("/*" + "=" * 70 + "*/")
        lines.append("")
        
        # Options
        lines.append("options mprint symbolgen mlogic;")
        lines.append("")
        
        # Define validation library
        lines.append(f'libname valout "{output_dir}";')
        lines.append("")
        
        # Add macros
        lines.append("/* === VALIDATION MACROS === */")
        lines.append(self.generate_table_snapshot_macro())
        lines.append(self.generate_table_compare_macro())
        lines.append("")
        
        # Phase 1: Run original code and capture outputs
        lines.append("/*" + "-" * 70 + "*/")
        lines.append("/* PHASE 1: RUN ORIGINAL CODE */")
        lines.append("/*" + "-" * 70 + "*/")
        lines.append("")
        lines.append(f'%include "{original_sas_path}";')
        lines.append("")
        
        # Capture snapshots of final tables
        lines.append("/* Capture snapshots of final output tables */")
        for table in self.final_tables:
            safe_name = table.replace('.', '_')
            lines.append(f"%table_snapshot(table={table}, prefix=orig_{safe_name}, outlib=valout);")
        lines.append("")
        
        # Clear work library for chunked run
        lines.append("/* Clear WORK library for chunked execution */")
        lines.append("proc datasets library=work kill nolist; quit;")
        lines.append("")
        
        # Phase 2: Run chunked code and capture outputs
        lines.append("/*" + "-" * 70 + "*/")
        lines.append("/* PHASE 2: RUN CHUNKED CODE */")
        lines.append("/*" + "-" * 70 + "*/")
        lines.append("")
        lines.append(f'%include "{split_sas_path}";')
        lines.append("")
        
        # Capture snapshots of final tables from chunked execution
        lines.append("/* Capture snapshots of final output tables from chunks */")
        for table in self.final_tables:
            safe_name = table.replace('.', '_')
            lines.append(f"%table_snapshot(table={table}, prefix=chunk_{safe_name}, outlib=valout);")
        lines.append("")
        
        # Phase 3: Compare outputs
        lines.append("/*" + "-" * 70 + "*/")
        lines.append("/* PHASE 3: COMPARE OUTPUTS */")
        lines.append("/*" + "-" * 70 + "*/")
        lines.append("")
        
        for table in self.final_tables:
            safe_name = table.replace('.', '_')
            lines.append(f"/* Compare {table} */")
            lines.append(f"%compare_tables(")
            lines.append(f"    base=valout.orig_{safe_name}_snapshot,")
            lines.append(f"    compare=valout.chunk_{safe_name}_snapshot,")
            lines.append(f"    outlib=valout,")
            lines.append(f"    report_name=cmp_{safe_name}")
            lines.append(f");")
            lines.append("")
        
        # Generate summary report
        lines.append("/*" + "-" * 70 + "*/")
        lines.append("/* PHASE 4: GENERATE VALIDATION REPORT */")
        lines.append("/*" + "-" * 70 + "*/")
        lines.append("")
        lines.append("data valout.validation_summary;")
        lines.append("    length table_name $50 status $20 original_rows chunk_rows 8;")
        
        for i, table in enumerate(self.final_tables):
            safe_name = table.replace('.', '_')
            if i == 0:
                lines.append(f'    table_name = "{table}";')
            else:
                lines.append(f'    table_name = "{table}";')
            lines.append(f"    status = symget('cmp_{safe_name}_match');")
            lines.append(f"    original_rows = input(symget('orig_{safe_name}_rowcount'), best.);")
            lines.append(f"    chunk_rows = input(symget('chunk_{safe_name}_rowcount'), best.);")
            lines.append("    output;")
            lines.append("")
        
        lines.append("run;")
        lines.append("")
        
        # Print summary
        lines.append("/* Print validation summary */")
        lines.append("proc print data=valout.validation_summary noobs;")
        lines.append("    title 'SAS CHUNK VALIDATION SUMMARY';")
        lines.append("run;")
        lines.append("")
        
        # Final status
        lines.append("/* Check overall validation status */")
        lines.append("proc sql noprint;")
        lines.append("    select count(*) into :failed_count")
        lines.append("    from valout.validation_summary")
        lines.append("    where status = 'FAILED';")
        lines.append("quit;")
        lines.append("")
        lines.append("%put;")
        lines.append("%put " + "=" * 60 + ";")
        lines.append("%if &failed_count > 0 %then %do;")
        lines.append("    %put ERROR: VALIDATION FAILED - &failed_count table(s) have differences;")
        lines.append("%end;")
        lines.append("%else %do;")
        lines.append("    %put NOTE: VALIDATION PASSED - All tables match;")
        lines.append("%end;")
        lines.append("%put " + "=" * 60 + ";")
        lines.append("%put;")
        
        return '\n'.join(lines)
    
    def generate_chunk_validation_sas(self, chunk_id: int) -> str:
        """
        Generate validation script for a specific chunk.
        
        Only generates validation for chunks that can be independently validated
        (i.e., their output tables are not overwritten).
        
        Args:
            chunk_id: The chunk ID to validate
            
        Returns:
            SAS validation code for the chunk, or empty string if not validatable
        """
        if chunk_id not in self.validation_ready:
            return f"/* Chunk {chunk_id} cannot be independently validated (output tables are overwritten) */"
        
        chunk = next((c for c in self.chunks if c['chunk_id'] == chunk_id), None)
        if not chunk:
            return f"/* Chunk {chunk_id} not found */"
        
        output_tables = [t for t in chunk['output_tables'] if not t['is_overwritten']]
        
        if not output_tables:
            return f"/* Chunk {chunk_id} has no validatable output tables */"
        
        lines = []
        lines.append(f"/* Validation for Chunk {chunk_id} */")
        lines.append(f"/* Output tables: {', '.join([t['name'] for t in output_tables])} */")
        lines.append("")
        
        for table in output_tables:
            table_name = f"{table['library']}.{table['name']}"
            safe_name = f"{table['library']}_{table['name']}"
            
            lines.append(f"%table_snapshot(table={table_name}, prefix=chunk{chunk_id}_{safe_name});")
        
        return '\n'.join(lines)


class PythonValidationHelper:
    """
    Helper class for Python-based validation.
    
    This is used when comparing outputs after the SAS-to-Python conversion,
    when both SAS output (as CSV/Parquet) and Python output need to be compared.
    """
    
    @staticmethod
    def compute_dataframe_hash(df) -> str:
        """Compute a hash of a pandas DataFrame for comparison"""
        import pandas as pd
        import hashlib
        
        # Sort columns and rows for consistent comparison
        df_sorted = df.sort_index(axis=1).sort_values(by=list(df.columns)).reset_index(drop=True)
        
        # Convert to string and hash
        content = df_sorted.to_csv(index=False)
        return hashlib.md5(content.encode()).hexdigest()
    
    @staticmethod
    def compare_dataframes(df1, df2, tolerance: float = 0.00001) -> Dict:
        """
        Compare two DataFrames and return detailed differences.
        
        Args:
            df1: First DataFrame
            df2: Second DataFrame
            tolerance: Numeric comparison tolerance
            
        Returns:
            Dictionary with comparison results
        """
        import pandas as pd
        import numpy as np
        
        result = {
            "match": True,
            "row_count_match": True,
            "column_match": True,
            "value_match": True,
            "differences": []
        }
        
        # Check row counts
        if len(df1) != len(df2):
            result["match"] = False
            result["row_count_match"] = False
            result["differences"].append(f"Row count mismatch: {len(df1)} vs {len(df2)}")
        
        # Check columns
        cols1 = set(df1.columns)
        cols2 = set(df2.columns)
        
        if cols1 != cols2:
            result["match"] = False
            result["column_match"] = False
            missing_in_2 = cols1 - cols2
            missing_in_1 = cols2 - cols1
            if missing_in_2:
                result["differences"].append(f"Columns in df1 but not df2: {missing_in_2}")
            if missing_in_1:
                result["differences"].append(f"Columns in df2 but not df1: {missing_in_1}")
        
        # Compare values for common columns
        common_cols = cols1 & cols2
        if common_cols and len(df1) == len(df2):
            for col in common_cols:
                if df1[col].dtype in [np.float64, np.float32]:
                    # Numeric comparison with tolerance
                    diff = np.abs(df1[col] - df2[col])
                    if diff.max() > tolerance:
                        result["match"] = False
                        result["value_match"] = False
                        result["differences"].append(
                            f"Column '{col}' has numeric differences (max diff: {diff.max():.6f})"
                        )
                else:
                    # Exact comparison for non-numeric
                    if not df1[col].equals(df2[col]):
                        result["match"] = False
                        result["value_match"] = False
                        mismatches = (df1[col] != df2[col]).sum()
                        result["differences"].append(
                            f"Column '{col}' has {mismatches} mismatched values"
                        )
        
        return result


def generate_validation_script(metadata_path: str, 
                                original_sas: str,
                                split_sas: str,
                                output_path: str) -> str:
    """
    Generate a validation SAS script.
    
    Args:
        metadata_path: Path to the metadata JSON
        original_sas: Path to original SAS file
        split_sas: Path to split SAS file
        output_path: Path to write the validation script
        
    Returns:
        Path to the generated script
    """
    generator = SASValidationGenerator(metadata_path)
    validation_sas = generator.generate_validation_sas(original_sas, split_sas)
    
    output_path = Path(output_path)
    with open(output_path, 'w') as f:
        f.write(validation_sas)
    
    return str(output_path)


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 4:
        print("Usage: python validation.py <metadata.json> <original.sas> <split.sas> [output.sas]")
        sys.exit(1)
    
    metadata = sys.argv[1]
    original = sys.argv[2]
    split = sys.argv[3]
    output = sys.argv[4] if len(sys.argv) > 4 else "validation.sas"
    
    result = generate_validation_script(metadata, original, split, output)
    print(f"Validation script generated: {result}")
