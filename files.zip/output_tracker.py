"""
Output Table Tracker for Snowflake Migration
=============================================
Tracks all output tables from SAS chunks and generates migration metadata
for Snowflake integration.

Features:
1. Identifies all output tables and their sources
2. Tracks table lineage (which chunks create/modify each table)
3. Generates Snowflake-compatible table definitions
4. Creates migration manifest for downstream processing

Author: SAS to Python Migration Team
"""

import json
import re
from dataclasses import dataclass, field
from typing import List, Dict, Set, Optional
from pathlib import Path
from datetime import datetime


@dataclass
class ColumnInfo:
    """Information about a table column"""
    name: str
    sas_type: str  # SAS type (character, numeric)
    length: Optional[int] = None
    format: Optional[str] = None
    informat: Optional[str] = None
    label: Optional[str] = None


@dataclass
class TableInfo:
    """Complete information about an output table"""
    name: str
    library: str
    chunk_ids: List[int]  # Chunks that write to this table
    is_final: bool  # Whether this is a final output (not overwritten)
    columns: List[ColumnInfo] = field(default_factory=list)
    estimated_rows: Optional[int] = None
    source_tables: List[str] = field(default_factory=list)
    snowflake_schema: Optional[str] = None
    snowflake_table: Optional[str] = None
    migration_notes: str = ""
    
    @property
    def full_name(self) -> str:
        return f"{self.library}.{self.name}"


@dataclass
class MigrationManifest:
    """Manifest for migrating tables to Snowflake"""
    source_file: str
    generation_timestamp: str
    tables: List[TableInfo]
    validation_status: str
    snowflake_database: str
    snowflake_schema: str


class OutputTableTracker:
    """
    Tracks output tables from SAS code and prepares them for Snowflake migration.
    """
    
    # SAS to Snowflake type mapping
    TYPE_MAPPING = {
        'character': 'VARCHAR',
        'char': 'VARCHAR',
        'numeric': 'NUMBER',
        'num': 'NUMBER',
        'date': 'DATE',
        'datetime': 'TIMESTAMP_NTZ',
        'time': 'TIME',
    }
    
    # SAS format to Snowflake type hints
    FORMAT_MAPPING = {
        'date': 'DATE',
        'datetime': 'TIMESTAMP_NTZ',
        'mmddyy': 'DATE',
        'yymmdd': 'DATE',
        'date9': 'DATE',
        'dollar': 'NUMBER(18,2)',
        'comma': 'NUMBER',
        'percent': 'NUMBER(10,4)',
    }
    
    def __init__(self, metadata_path: str = None):
        """
        Initialize the tracker.
        
        Args:
            metadata_path: Optional path to metadata JSON from splitter
        """
        self.tables: Dict[str, TableInfo] = {}
        self.chunk_outputs: Dict[int, List[str]] = {}  # chunk_id -> [table names]
        
        if metadata_path:
            self.load_from_metadata(metadata_path)
    
    def load_from_metadata(self, metadata_path: str) -> None:
        """Load table information from splitter metadata"""
        with open(metadata_path, 'r') as f:
            metadata = json.load(f)
        
        chunks = metadata['chunks']
        final_tables = set(metadata['final_output_tables'])
        overwritten = set(metadata['overwritten_tables'])
        
        for chunk in chunks:
            chunk_id = chunk['chunk_id']
            self.chunk_outputs[chunk_id] = []
            
            for table in chunk['output_tables']:
                full_name = f"{table['library']}.{table['name']}"
                self.chunk_outputs[chunk_id].append(full_name)
                
                if full_name not in self.tables:
                    self.tables[full_name] = TableInfo(
                        name=table['name'],
                        library=table['library'],
                        chunk_ids=[chunk_id],
                        is_final=(full_name in final_tables),
                        source_tables=[]
                    )
                else:
                    self.tables[full_name].chunk_ids.append(chunk_id)
                
                # Track if this table is overwritten
                if table.get('is_overwritten'):
                    self.tables[full_name].migration_notes += f"Overwritten by chunk {table.get('overwritten_by_chunk')}. "
    
    def extract_columns_from_code(self, sas_code: str, table_name: str) -> List[ColumnInfo]:
        """
        Extract column information from SAS code.
        
        This is a best-effort extraction; actual column info may need
        to be obtained from SAS dictionary tables at runtime.
        """
        columns = []
        
        # Look for LENGTH statements
        length_pattern = re.compile(
            r'length\s+([^;]+);',
            re.IGNORECASE | re.DOTALL
        )
        
        length_match = length_pattern.search(sas_code)
        if length_match:
            length_clause = length_match.group(1)
            # Parse individual column definitions
            col_pattern = re.compile(r'(\w+)\s+(\$?)(\d+)?')
            for match in col_pattern.finditer(length_clause):
                col_name = match.group(1)
                is_char = bool(match.group(2))
                length = int(match.group(3)) if match.group(3) else None
                
                columns.append(ColumnInfo(
                    name=col_name.upper(),
                    sas_type='character' if is_char else 'numeric',
                    length=length
                ))
        
        # Look for FORMAT statements
        format_pattern = re.compile(
            r'format\s+([^;]+);',
            re.IGNORECASE | re.DOTALL
        )
        
        format_match = format_pattern.search(sas_code)
        if format_match:
            format_clause = format_match.group(1)
            # Parse format assignments
            fmt_pattern = re.compile(r'(\w+)\s+(\w+\d*\.?\d*)')
            for match in fmt_pattern.finditer(format_clause):
                col_name = match.group(1).upper()
                format_str = match.group(2)
                
                # Update existing column or create new
                existing = next((c for c in columns if c.name == col_name), None)
                if existing:
                    existing.format = format_str
                else:
                    columns.append(ColumnInfo(
                        name=col_name,
                        sas_type='numeric',  # Default
                        format=format_str
                    ))
        
        return columns
    
    def infer_snowflake_type(self, column: ColumnInfo) -> str:
        """Infer the best Snowflake type for a SAS column"""
        # Check format first for type hints
        if column.format:
            format_lower = column.format.lower()
            for sas_fmt, sf_type in self.FORMAT_MAPPING.items():
                if sas_fmt in format_lower:
                    return sf_type
        
        # Use basic type mapping
        base_type = self.TYPE_MAPPING.get(column.sas_type.lower(), 'VARCHAR')
        
        if base_type == 'VARCHAR' and column.length:
            return f'VARCHAR({column.length})'
        elif base_type == 'NUMBER' and column.length:
            return f'NUMBER({column.length})'
        
        return base_type
    
    def generate_snowflake_ddl(self, table: TableInfo, 
                                database: str = "SAS_MIGRATION",
                                schema: str = "PUBLIC") -> str:
        """
        Generate Snowflake DDL for a table.
        
        Args:
            table: TableInfo object
            database: Target Snowflake database
            schema: Target Snowflake schema
            
        Returns:
            CREATE TABLE statement
        """
        full_name = f"{database}.{schema}.{table.name}"
        
        if not table.columns:
            # If no column info, create a placeholder
            return f"""-- Table: {full_name}
-- NOTE: Column definitions need to be extracted from SAS runtime
-- Source chunks: {table.chunk_ids}
-- Is final output: {table.is_final}

CREATE TABLE IF NOT EXISTS {full_name} (
    -- Column definitions to be added after SAS metadata extraction
    _placeholder VARCHAR(1)
);
"""
        
        column_defs = []
        for col in table.columns:
            sf_type = self.infer_snowflake_type(col)
            comment = f" -- SAS format: {col.format}" if col.format else ""
            column_defs.append(f"    {col.name} {sf_type}{comment}")
        
        columns_str = ",\n".join(column_defs)
        
        return f"""-- Table: {full_name}
-- Source SAS library: {table.library}
-- Source chunks: {table.chunk_ids}
-- Is final output: {table.is_final}

CREATE TABLE IF NOT EXISTS {full_name} (
{columns_str}
);
"""
    
    def generate_migration_manifest(self, 
                                     source_file: str,
                                     database: str = "SAS_MIGRATION",
                                     schema: str = "PUBLIC") -> Dict:
        """
        Generate a migration manifest for all tracked tables.
        
        Args:
            source_file: Source SAS file name
            database: Target Snowflake database
            schema: Target Snowflake schema
            
        Returns:
            Dictionary manifest suitable for JSON serialization
        """
        manifest = {
            "source_file": source_file,
            "generation_timestamp": datetime.now().isoformat(),
            "snowflake_database": database,
            "snowflake_schema": schema,
            "total_tables": len(self.tables),
            "final_output_tables": sum(1 for t in self.tables.values() if t.is_final),
            "intermediate_tables": sum(1 for t in self.tables.values() if not t.is_final),
            "tables": []
        }
        
        for full_name, table in self.tables.items():
            table_entry = {
                "sas_name": full_name,
                "sas_library": table.library,
                "sas_table": table.name,
                "snowflake_table": f"{database}.{schema}.{table.name}",
                "source_chunks": table.chunk_ids,
                "is_final_output": table.is_final,
                "can_validate": table.is_final,  # Only final outputs can be validated
                "migration_notes": table.migration_notes or "None",
                "columns": [
                    {
                        "name": col.name,
                        "sas_type": col.sas_type,
                        "sas_format": col.format,
                        "snowflake_type": self.infer_snowflake_type(col)
                    }
                    for col in table.columns
                ]
            }
            manifest["tables"].append(table_entry)
        
        return manifest
    
    def export_manifest(self, output_path: str, source_file: str,
                        database: str = "SAS_MIGRATION",
                        schema: str = "PUBLIC") -> str:
        """Export the migration manifest to a JSON file"""
        manifest = self.generate_migration_manifest(source_file, database, schema)
        
        with open(output_path, 'w') as f:
            json.dump(manifest, f, indent=2)
        
        return output_path
    
    def export_ddl(self, output_path: str,
                   database: str = "SAS_MIGRATION",
                   schema: str = "PUBLIC") -> str:
        """Export Snowflake DDL for all tables"""
        ddl_statements = []
        
        # Add header
        ddl_statements.append(f"-- Snowflake DDL for SAS Migration")
        ddl_statements.append(f"-- Generated: {datetime.now().isoformat()}")
        ddl_statements.append(f"-- Database: {database}")
        ddl_statements.append(f"-- Schema: {schema}")
        ddl_statements.append("")
        ddl_statements.append(f"CREATE DATABASE IF NOT EXISTS {database};")
        ddl_statements.append(f"CREATE SCHEMA IF NOT EXISTS {database}.{schema};")
        ddl_statements.append("")
        
        # Add table DDL
        for table in self.tables.values():
            ddl_statements.append(self.generate_snowflake_ddl(table, database, schema))
        
        with open(output_path, 'w') as f:
            f.write('\n'.join(ddl_statements))
        
        return output_path
    
    def get_validation_eligible_tables(self) -> List[str]:
        """Get list of tables that can be used for validation"""
        return [name for name, table in self.tables.items() if table.is_final]
    
    def get_overwritten_tables(self) -> Dict[str, List[int]]:
        """Get tables that are overwritten and which chunks overwrite them"""
        overwritten = {}
        for name, table in self.tables.items():
            if len(table.chunk_ids) > 1:
                overwritten[name] = table.chunk_ids
        return overwritten
    
    def print_summary(self) -> None:
        """Print a summary of tracked tables"""
        print("\n" + "=" * 60)
        print("OUTPUT TABLE TRACKING SUMMARY")
        print("=" * 60)
        print(f"Total tables tracked: {len(self.tables)}")
        print(f"Final output tables: {sum(1 for t in self.tables.values() if t.is_final)}")
        print(f"Intermediate tables: {sum(1 for t in self.tables.values() if not t.is_final)}")
        
        print("\n--- Final Output Tables (for Snowflake) ---")
        for name, table in self.tables.items():
            if table.is_final:
                print(f"  {name} (created by chunk(s): {table.chunk_ids})")
        
        print("\n--- Overwritten Tables (intermediate) ---")
        for name, table in self.tables.items():
            if not table.is_final:
                print(f"  {name} (written by chunks: {table.chunk_ids})")
        
        print("=" * 60 + "\n")


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: python output_tracker.py <metadata.json> [--ddl output.sql] [--manifest output.json]")
        sys.exit(1)
    
    metadata_path = sys.argv[1]
    
    tracker = OutputTableTracker(metadata_path)
    tracker.print_summary()
    
    # Handle optional outputs
    if '--ddl' in sys.argv:
        idx = sys.argv.index('--ddl')
        ddl_path = sys.argv[idx + 1] if idx + 1 < len(sys.argv) else "snowflake_ddl.sql"
        tracker.export_ddl(ddl_path)
        print(f"DDL exported to: {ddl_path}")
    
    if '--manifest' in sys.argv:
        idx = sys.argv.index('--manifest')
        manifest_path = sys.argv[idx + 1] if idx + 1 < len(sys.argv) else "migration_manifest.json"
        tracker.export_manifest(manifest_path, "source.sas")
        print(f"Manifest exported to: {manifest_path}")
