#!/usr/bin/env python3
"""
SAS Code Splitter - Main CLI Tool
==================================
MVP Version 1: Decomposes SAS code into smaller chunks without regression.

Usage:
    python main.py split <input.sas> [--output-dir <dir>] [--verbose]
    python main.py validate <metadata.json> <original.sas> <split.sas>
    python main.py track <metadata.json> [--ddl] [--manifest]
    python main.py full <input.sas> [--output-dir <dir>] [--snowflake-db <db>]

Author: SAS to Python Migration Team
"""

import argparse
import sys
import json
from pathlib import Path
from datetime import datetime

from sas_code_splitter import SASCodeSplitter, split_sas_file
from validation import SASValidationGenerator, generate_validation_script
from output_tracker import OutputTableTracker


class SASChunkerCLI:
    """Main CLI orchestrator for the SAS Code Splitter"""
    
    def __init__(self):
        self.parser = self._create_parser()
    
    def _create_parser(self) -> argparse.ArgumentParser:
        """Create the argument parser"""
        parser = argparse.ArgumentParser(
            description="SAS Code Splitter - MVP Version 1",
            formatter_class=argparse.RawDescriptionHelpFormatter,
            epilog="""
Examples:
  # Split a SAS file into chunks
  python main.py split my_script.sas --output-dir ./output --verbose
  
  # Generate validation script
  python main.py validate output/my_script_metadata.json my_script.sas output/my_script_split.sas
  
  # Track output tables for Snowflake migration
  python main.py track output/my_script_metadata.json --ddl --manifest
  
  # Full pipeline: split, validate, track
  python main.py full my_script.sas --output-dir ./output --snowflake-db MY_DB
"""
        )
        
        subparsers = parser.add_subparsers(dest='command', help='Commands')
        
        # Split command
        split_parser = subparsers.add_parser('split', help='Split SAS code into chunks')
        split_parser.add_argument('input_file', help='Input SAS file')
        split_parser.add_argument('--output-dir', '-o', default='.', help='Output directory')
        split_parser.add_argument('--verbose', '-v', action='store_true', help='Verbose output')
        
        # Validate command
        validate_parser = subparsers.add_parser('validate', help='Generate validation script')
        validate_parser.add_argument('metadata', help='Metadata JSON from split')
        validate_parser.add_argument('original', help='Original SAS file')
        validate_parser.add_argument('split', help='Split SAS file')
        validate_parser.add_argument('--output', '-o', default=None, help='Output validation script')
        
        # Track command
        track_parser = subparsers.add_parser('track', help='Track output tables')
        track_parser.add_argument('metadata', help='Metadata JSON from split')
        track_parser.add_argument('--ddl', action='store_true', help='Generate Snowflake DDL')
        track_parser.add_argument('--manifest', action='store_true', help='Generate migration manifest')
        track_parser.add_argument('--output-dir', '-o', default='.', help='Output directory')
        track_parser.add_argument('--snowflake-db', default='SAS_MIGRATION', help='Snowflake database name')
        track_parser.add_argument('--snowflake-schema', default='PUBLIC', help='Snowflake schema name')
        
        # Full pipeline command
        full_parser = subparsers.add_parser('full', help='Run full pipeline')
        full_parser.add_argument('input_file', help='Input SAS file')
        full_parser.add_argument('--output-dir', '-o', default='./output', help='Output directory')
        full_parser.add_argument('--snowflake-db', default='SAS_MIGRATION', help='Snowflake database')
        full_parser.add_argument('--snowflake-schema', default='PUBLIC', help='Snowflake schema')
        full_parser.add_argument('--verbose', '-v', action='store_true', help='Verbose output')
        
        # Report command
        report_parser = subparsers.add_parser('report', help='Generate summary report')
        report_parser.add_argument('metadata', help='Metadata JSON from split')
        report_parser.add_argument('--format', choices=['text', 'json', 'html'], default='text')
        
        return parser
    
    def run(self, args=None):
        """Run the CLI"""
        args = self.parser.parse_args(args)
        
        if args.command is None:
            self.parser.print_help()
            return 1
        
        if args.command == 'split':
            return self.cmd_split(args)
        elif args.command == 'validate':
            return self.cmd_validate(args)
        elif args.command == 'track':
            return self.cmd_track(args)
        elif args.command == 'full':
            return self.cmd_full(args)
        elif args.command == 'report':
            return self.cmd_report(args)
        
        return 0
    
    def cmd_split(self, args) -> int:
        """Handle the split command"""
        print(f"\n{'='*60}")
        print("SAS CODE SPLITTER - MVP Version 1")
        print(f"{'='*60}")
        print(f"Input file: {args.input_file}")
        print(f"Output directory: {args.output_dir}")
        print(f"{'='*60}\n")
        
        try:
            result = split_sas_file(args.input_file, args.output_dir, args.verbose)
            
            print(f"\n{'='*60}")
            print("SPLIT COMPLETE")
            print(f"{'='*60}")
            print(f"Total chunks created: {len(result.chunks)}")
            print(f"Output tables identified: {len(result.all_output_tables)}")
            print(f"Overwritten tables: {len(result.overwritten_tables)}")
            print(f"Final output tables: {len(result.final_output_tables)}")
            print(f"Validation-ready chunks: {len(result.validation_ready_chunks)}")
            
            print(f"\n--- Output Files ---")
            base_name = Path(args.input_file).stem
            output_dir = Path(args.output_dir)
            print(f"Split SAS: {output_dir / f'{base_name}_split.sas'}")
            print(f"Metadata: {output_dir / f'{base_name}_metadata.json'}")
            
            print(f"\n--- Final Output Tables (for Snowflake) ---")
            for table in result.final_output_tables:
                print(f"  - {table}")
            
            if result.overwritten_tables:
                print(f"\n--- Overwritten Tables (cannot validate independently) ---")
                for table in result.overwritten_tables:
                    chunks = result.all_output_tables.get(table, [])
                    print(f"  - {table} (written by chunks: {chunks})")
            
            print(f"{'='*60}\n")
            return 0
            
        except Exception as e:
            print(f"ERROR: {e}")
            if args.verbose:
                import traceback
                traceback.print_exc()
            return 1
    
    def cmd_validate(self, args) -> int:
        """Handle the validate command"""
        print(f"\n{'='*60}")
        print("VALIDATION SCRIPT GENERATOR")
        print(f"{'='*60}")
        
        try:
            output_path = args.output
            if output_path is None:
                base_name = Path(args.original).stem
                output_path = f"{base_name}_validation.sas"
            
            result = generate_validation_script(
                args.metadata,
                args.original,
                args.split,
                output_path
            )
            
            print(f"Validation script generated: {result}")
            print(f"\nTo validate, run this script in SAS:")
            print(f"  %include '{result}';")
            print(f"{'='*60}\n")
            return 0
            
        except Exception as e:
            print(f"ERROR: {e}")
            return 1
    
    def cmd_track(self, args) -> int:
        """Handle the track command"""
        print(f"\n{'='*60}")
        print("OUTPUT TABLE TRACKER")
        print(f"{'='*60}")
        
        try:
            tracker = OutputTableTracker(args.metadata)
            tracker.print_summary()
            
            output_dir = Path(args.output_dir)
            output_dir.mkdir(parents=True, exist_ok=True)
            
            with open(args.metadata, 'r') as f:
                metadata = json.load(f)
            source_file = metadata.get('original_file', 'unknown.sas')
            
            if args.ddl:
                ddl_path = output_dir / f"{Path(source_file).stem}_snowflake.sql"
                tracker.export_ddl(str(ddl_path), args.snowflake_db, args.snowflake_schema)
                print(f"Snowflake DDL: {ddl_path}")
            
            if args.manifest:
                manifest_path = output_dir / f"{Path(source_file).stem}_manifest.json"
                tracker.export_manifest(str(manifest_path), source_file, 
                                       args.snowflake_db, args.snowflake_schema)
                print(f"Migration manifest: {manifest_path}")
            
            print(f"{'='*60}\n")
            return 0
            
        except Exception as e:
            print(f"ERROR: {e}")
            return 1
    
    def cmd_full(self, args) -> int:
        """Handle the full pipeline command"""
        print(f"\n{'='*60}")
        print("SAS CODE SPLITTER - FULL PIPELINE")
        print(f"{'='*60}")
        print(f"Input: {args.input_file}")
        print(f"Output directory: {args.output_dir}")
        print(f"Snowflake target: {args.snowflake_db}.{args.snowflake_schema}")
        print(f"{'='*60}\n")
        
        output_dir = Path(args.output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        base_name = Path(args.input_file).stem
        
        # Step 1: Split
        print("STEP 1: Splitting SAS code...")
        try:
            result = split_sas_file(args.input_file, str(output_dir), args.verbose)
            print(f"  ✓ Created {len(result.chunks)} chunks")
            print(f"  ✓ Identified {len(result.all_output_tables)} output tables")
        except Exception as e:
            print(f"  ✗ Split failed: {e}")
            return 1
        
        # Step 2: Track output tables
        print("\nSTEP 2: Tracking output tables...")
        try:
            metadata_path = output_dir / f"{base_name}_metadata.json"
            tracker = OutputTableTracker(str(metadata_path))
            
            # Export DDL
            ddl_path = output_dir / f"{base_name}_snowflake.sql"
            tracker.export_ddl(str(ddl_path), args.snowflake_db, args.snowflake_schema)
            print(f"  ✓ Generated Snowflake DDL: {ddl_path}")
            
            # Export manifest
            manifest_path = output_dir / f"{base_name}_manifest.json"
            tracker.export_manifest(str(manifest_path), args.input_file,
                                   args.snowflake_db, args.snowflake_schema)
            print(f"  ✓ Generated migration manifest: {manifest_path}")
        except Exception as e:
            print(f"  ✗ Tracking failed: {e}")
            return 1
        
        # Step 3: Generate validation script
        print("\nSTEP 3: Generating validation script...")
        try:
            split_sas_path = output_dir / f"{base_name}_split.sas"
            validation_path = output_dir / f"{base_name}_validation.sas"
            
            generate_validation_script(
                str(metadata_path),
                args.input_file,
                str(split_sas_path),
                str(validation_path)
            )
            print(f"  ✓ Generated validation script: {validation_path}")
        except Exception as e:
            print(f"  ✗ Validation generation failed: {e}")
            return 1
        
        # Summary
        print(f"\n{'='*60}")
        print("PIPELINE COMPLETE")
        print(f"{'='*60}")
        print(f"\nGenerated files:")
        print(f"  • Split SAS code: {output_dir / f'{base_name}_split.sas'}")
        print(f"  • Metadata JSON: {output_dir / f'{base_name}_metadata.json'}")
        print(f"  • Snowflake DDL: {output_dir / f'{base_name}_snowflake.sql'}")
        print(f"  • Migration manifest: {output_dir / f'{base_name}_manifest.json'}")
        print(f"  • Validation script: {output_dir / f'{base_name}_validation.sas'}")
        
        print(f"\n--- Summary ---")
        print(f"Total chunks: {len(result.chunks)}")
        print(f"Final output tables (for Snowflake): {len(result.final_output_tables)}")
        for table in result.final_output_tables:
            print(f"  - {table}")
        
        print(f"\nValidation-ready chunks: {len(result.validation_ready_chunks)}")
        if result.overwritten_tables:
            print(f"Tables with overwrites (require sequential validation): {len(result.overwritten_tables)}")
        
        print(f"\n--- Next Steps ---")
        print(f"1. Run validation in SAS: %include '{validation_path}';")
        print(f"2. Review Snowflake DDL and adjust types as needed")
        print(f"3. Use chunks for SAS-to-Python conversion")
        print(f"{'='*60}\n")
        
        return 0
    
    def cmd_report(self, args) -> int:
        """Handle the report command"""
        try:
            with open(args.metadata, 'r') as f:
                metadata = json.load(f)
            
            if args.format == 'json':
                print(json.dumps(metadata, indent=2))
            elif args.format == 'html':
                self._generate_html_report(metadata)
            else:
                self._generate_text_report(metadata)
            
            return 0
        except Exception as e:
            print(f"ERROR: {e}")
            return 1
    
    def _generate_text_report(self, metadata: dict) -> None:
        """Generate a text format report"""
        print(f"\n{'='*60}")
        print("SAS CHUNK ANALYSIS REPORT")
        print(f"{'='*60}")
        print(f"Source file: {metadata['original_file']}")
        print(f"Split file: {metadata['split_file']}")
        print(f"Generated: {metadata['metadata']['split_timestamp']}")
        
        print(f"\n--- Statistics ---")
        print(f"Total chunks: {metadata['metadata']['total_chunks']}")
        print(f"Total output tables: {metadata['metadata']['total_output_tables']}")
        print(f"Overwritten tables: {metadata['metadata']['overwritten_tables_count']}")
        print(f"Validation-ready chunks: {metadata['metadata']['validation_ready_count']}")
        
        print(f"\n--- Chunks ---")
        for chunk in metadata['chunks']:
            print(f"\nChunk {chunk['chunk_id']} ({chunk['chunk_type']})")
            print(f"  Lines: {chunk['start_line']}-{chunk['end_line']}")
            print(f"  Outputs: {[t['name'] for t in chunk['output_tables']]}")
            print(f"  Inputs: {[t['name'] for t in chunk['input_tables']]}")
            print(f"  Can validate: {chunk['can_validate_independently']}")
            if chunk['validation_notes']:
                print(f"  Notes: {chunk['validation_notes']}")
        
        print(f"\n--- Final Output Tables ---")
        for table in metadata['final_output_tables']:
            print(f"  - {table}")
        
        print(f"{'='*60}\n")
    
    def _generate_html_report(self, metadata: dict) -> None:
        """Generate an HTML format report"""
        html = f"""<!DOCTYPE html>
<html>
<head>
    <title>SAS Chunk Analysis Report</title>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 20px; }}
        h1 {{ color: #333; }}
        .stats {{ background: #f5f5f5; padding: 15px; border-radius: 5px; }}
        .chunk {{ border: 1px solid #ddd; margin: 10px 0; padding: 15px; border-radius: 5px; }}
        .chunk-header {{ font-weight: bold; color: #0066cc; }}
        .table-list {{ color: #666; }}
        .warning {{ color: #cc6600; }}
        table {{ border-collapse: collapse; width: 100%; }}
        th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
        th {{ background: #f0f0f0; }}
    </style>
</head>
<body>
    <h1>SAS Chunk Analysis Report</h1>
    
    <div class="stats">
        <p><strong>Source:</strong> {metadata['original_file']}</p>
        <p><strong>Split file:</strong> {metadata['split_file']}</p>
        <p><strong>Generated:</strong> {metadata['metadata']['split_timestamp']}</p>
        <p><strong>Total chunks:</strong> {metadata['metadata']['total_chunks']}</p>
        <p><strong>Output tables:</strong> {metadata['metadata']['total_output_tables']}</p>
    </div>
    
    <h2>Chunks</h2>
"""
        
        for chunk in metadata['chunks']:
            outputs = ', '.join([t['name'] for t in chunk['output_tables']]) or 'None'
            inputs = ', '.join([t['name'] for t in chunk['input_tables']]) or 'None'
            validation_class = '' if chunk['can_validate_independently'] else 'warning'
            
            html += f"""
    <div class="chunk">
        <div class="chunk-header">Chunk {chunk['chunk_id']}: {chunk['chunk_type']}</div>
        <p>Lines {chunk['start_line']}-{chunk['end_line']}</p>
        <p class="table-list">Outputs: {outputs}</p>
        <p class="table-list">Inputs: {inputs}</p>
        <p class="{validation_class}">Can validate independently: {chunk['can_validate_independently']}</p>
    </div>
"""
        
        html += f"""
    <h2>Final Output Tables</h2>
    <ul>
"""
        for table in metadata['final_output_tables']:
            html += f"        <li>{table}</li>\n"
        
        html += """
    </ul>
</body>
</html>
"""
        print(html)


def main():
    """Main entry point"""
    cli = SASChunkerCLI()
    sys.exit(cli.run())


if __name__ == "__main__":
    main()
